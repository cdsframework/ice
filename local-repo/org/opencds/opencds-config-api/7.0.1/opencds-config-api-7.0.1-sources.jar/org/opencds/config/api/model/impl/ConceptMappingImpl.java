/*
 * Copyright 2014-2020 OpenCDS.org
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.opencds.config.api.model.impl;

import org.opencds.config.api.model.Concept;
import org.opencds.config.api.model.ConceptMapping;

import java.util.ArrayList;
import java.util.List;

public record ConceptMappingImpl(ConceptImpl toConcept,
                                 List<Concept> fromConcepts) implements ConceptMapping {
    public ConceptMappingImpl {
        assert toConcept != null;
        assert fromConcepts != null && !fromConcepts.isEmpty();
    }

    public static ConceptMappingImpl create(Concept toConcept, List<Concept> fromConcepts) {
        return new ConceptMappingImpl(
                ConceptImpl.create(toConcept),
                ConceptImpl.create(fromConcepts));
    }

    public static ConceptMappingImpl create(ConceptMapping cm) {
        if (cm == null) {
            return null;
        }
        if (cm instanceof ConceptMappingImpl conceptMappingImpl) {
            return conceptMappingImpl;
        }
        return create(cm.getToConcept(), cm.getFromConcepts());
    }

    public static List<ConceptMapping> create(List<ConceptMapping> conceptMappings) {
        if (conceptMappings == null) {
            return null;
        }
        var cmis = new ArrayList<ConceptMapping>();
        for (var cm : conceptMappings) {
            cmis.add(ConceptMappingImpl.create(cm));
        }
        return cmis;
    }

    @Override
    public Concept getToConcept() {
        return toConcept;
    }

    @Override
    public List<Concept> getFromConcepts() {
        return fromConcepts;
    }
}
